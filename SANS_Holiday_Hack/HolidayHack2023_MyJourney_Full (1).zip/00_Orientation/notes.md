# 00 – Orientation

**Challenge:** Interact with Jingle Ringford, collect the starfish badge, grab a fishing pole, and complete the Cranberry Pi terminal challenge.

**Steps I Took:**
- I found Jingle Ringford near the dock and spoke with him to begin the onboarding sequence.
- After our chat, I picked up the starfish badge which unlocked the objective panel.
- On the beach, I picked up a fishing rod which seemed like it might be useful later.
- At the Cranberry Pi terminal, I simply typed `answer` to wrap up the challenge.

**Result:** The orientation steps were marked as complete, and I gained access to the full challenge UI.

**Lesson Learned:** This part was mostly about getting used to the game layout and interfaces. Quick and easy start.
