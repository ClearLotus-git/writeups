# 01 – Snowball Fight

**Challenge:** Defend the island from snowball-wielding drones using a web-based game.

**Steps I Took:**
- Accessed the Snowball Fight game on Frosty’s beach.
- I aimed using the mouse and timed my throws carefully, hitting drones mid-flight.
- After multiple attempts, I learned the best way was to lead the drone slightly before tossing the snowball.

**Result:** Once enough drones were hit, the game confirmed the challenge was complete.

**Lesson Learned:** Simple but fun—this required quick reaction time and some practice with aim and trajectory.
