# 05 – Luggage Lock

**Challenge:** Crack a 3-digit combination lock by finding the correct code from available hints.

**Steps I Took:**
- Searched around the environment for any clues or patterns involving numbers.
- Used the provided lockpad interface to try different combos.
- Eventually identified a pattern tied to a piece of paper nearby, which gave the correct combination.

**Result:** Lock opened and challenge marked complete after entering the right 3-digit code.

**Lesson Learned:** Pay attention to small visual hints. Sometimes the answer is hidden in plain sight.
